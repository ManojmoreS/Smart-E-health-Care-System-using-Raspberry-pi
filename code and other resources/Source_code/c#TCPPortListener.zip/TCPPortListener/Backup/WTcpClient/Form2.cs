using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Net.Sockets ;
using System.Net ;
using System.Threading ;
using System.Text;
using System.Xml;
using System.IO;

namespace WTcpClient
{
	public struct Issue
	{
		public string symbol;
		public string bid;
		public string offer;
		public string volume;
	}
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private Encoding ASCII = Encoding.ASCII;
		private Thread t;
		private Socket s;
		Issue isu = new Issue();
		static AutoResetEvent JobDone = new AutoResetEvent(false);
		MethodInvoker miv;
//		Char endOfMsg = '\n';// 13 is return


		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuConn;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.MenuItem menuExit;
		private System.Windows.Forms.MenuItem menuDisConnect;
		private System.Windows.Forms.ColumnHeader UserName;
		private System.Windows.Forms.ColumnHeader Title;
		private System.Windows.Forms.ColumnHeader EmpName;
		private System.Windows.Forms.ColumnHeader PhoneNum;
		private System.Windows.Forms.StatusBar sbar;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuExit = new System.Windows.Forms.MenuItem();
			this.menuConn = new System.Windows.Forms.MenuItem();
			this.menuDisConnect = new System.Windows.Forms.MenuItem();
			this.EmpName = new System.Windows.Forms.ColumnHeader();
			this.UserName = new System.Windows.Forms.ColumnHeader();
			this.Title = new System.Windows.Forms.ColumnHeader();
			this.sbar = new System.Windows.Forms.StatusBar();
			this.PhoneNum = new System.Windows.Forms.ColumnHeader();
			this.listView1 = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuConn,
																					  this.menuDisConnect});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuExit});
			this.menuItem1.Text = "File";
			// 
			// menuExit
			// 
			this.menuExit.Index = 0;
			this.menuExit.Text = "Exit";
			this.menuExit.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuConn
			// 
			this.menuConn.Index = 1;
			this.menuConn.Text = "Connect";
			this.menuConn.Click += new System.EventHandler(this.menuConn_Click);
			// 
			// menuDisConnect
			// 
			this.menuDisConnect.Index = 2;
			this.menuDisConnect.Text = "DisConnect";
			this.menuDisConnect.Click += new System.EventHandler(this.menuDisConnect_Click);
			// 
			// EmpName
			// 
			this.EmpName.Text = "Offer";
			this.EmpName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.EmpName.Width = 69;
			// 
			// UserName
			// 
			this.UserName.Text = "Symbol";
			this.UserName.Width = 54;
			// 
			// Title
			// 
			this.Title.Text = "Bid";
			this.Title.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.Title.Width = 66;
			// 
			// sbar
			// 
			this.sbar.Location = new System.Drawing.Point(0, 205);
			this.sbar.Name = "sbar";
			this.sbar.Size = new System.Drawing.Size(296, 20);
			this.sbar.TabIndex = 1;
			this.sbar.Text = "Click Connect";
			// 
			// PhoneNum
			// 
			this.PhoneNum.Text = "Volume";
			this.PhoneNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.PhoneNum.Width = 86;
			// 
			// listView1
			// 
			this.listView1.BackColor = System.Drawing.Color.WhiteSmoke;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.UserName,
																						this.Title,
																						this.EmpName,
																						this.PhoneNum});
			this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(8, 8);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(280, 192);
			this.listView1.TabIndex = 0;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(296, 225);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.sbar,
																		  this.listView1});
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "TcpClient";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void menuConn_Click(object sender, System.EventArgs e)
		{
			ConnectDlg myDlg = new ConnectDlg();
			myDlg.ShowDialog(this);
			if( myDlg.DialogResult==DialogResult.OK)
			{
				s = new Socket(AddressFamily.InterNetwork, SocketType.Stream,
					ProtocolType.Tcp );

				IPAddress hostadd = IPAddress.Parse(myDlg.IpAdd);
				int port=Int32.Parse(myDlg.PortNum);
				IPEndPoint EPhost = new IPEndPoint(hostadd, port);

				try
				{
					s.Connect(EPhost);
				
					if (s.Connected)
					{
						Byte[] bBuf;
						string buf;
						buf = String.Format("{0}:{1}", myDlg.UserName, myDlg.PassWord);
						bBuf=ASCII.GetBytes(buf);
						s.Send(bBuf, 0 , bBuf.Length,0);
						t = new Thread(new ThreadStart(StartRecieve));
						t.Start();
						sbar.Text="Ready to recieve data";
						menuConn.Enabled=false;
					}
				}
				catch (Exception e1) 
				{
					MessageBox.Show(e1.ToString());
				}
			}
		}
		private void StartRecieve()
		{
			miv = new MethodInvoker(this.UpdateListView);
			int cnt=0;
			string tmp=null;
			Byte[] firstb= new Byte[1];
			while (true)
			{
				try
				{
					Byte[] receive = new Byte[1];
					int ret = s.Receive(receive, 1, 0);
					if (ret > 0)
					{
						switch(receive[0]) 
						{
							case 11: //check start message
								cnt=0;
								break;
							case 10: // check end message
								cnt=0;
								if(firstb[0] == ':')
									HandleCommand(tmp);
								else if(firstb[0] == '<')
									HandleXml(tmp);
								else
									HandleText(tmp);
								tmp=null;
								break;
							default:
								if (cnt == 0)
									firstb[0] = receive[0];
								tmp += System.Text.Encoding.ASCII.GetString(receive);
								cnt++;
								break;
						}
					}
				}
				catch (Exception e) 
				{
					if( !s.Connected )
					{
						menuConn.Enabled=true;
						break;
					}
				}
			}
			t.Abort();
		}
		void HandleCommand(string str)
		{
			menuConn.Enabled=true;
			sbar.Text = Mid(str, 1, str.Length -1);;
		}
		void HandleXml(string str)
		{
			int textCount =0;
			StringReader stream = new StringReader(str);
			XmlTextReader tr = new XmlTextReader(stream);
			while(tr.Read())
			{
				switch (tr.NodeType)
				{
					case XmlNodeType.Element:
//						tmp2 = tr.Name;
						break;
					case XmlNodeType.Text:
					switch(++textCount) 
					{
						case 1:
							isu.symbol=tr.Value;
							break;
						case 2:
							isu.bid=tr.Value;
							break;
						case 3:
							isu.offer=tr.Value;
							break;
						case 4:
							isu.volume=tr.Value;
							break;
					}
						break;
				}
			}
			this.BeginInvoke(miv);
			JobDone.WaitOne();
		}
		void HandleText(string str)
		{
			isu.symbol= Mid(str, 0, 4).TrimEnd(' ');
			isu.bid = Mid(str, 4, 5).TrimEnd(' ');
			isu.offer = Mid(str, 9, 5).TrimEnd(' ');
			isu.volume = Mid(str, 16, str.Length-16).TrimEnd(' ');
			this.BeginInvoke(miv);
			Thread.Sleep(300);
			JobDone.WaitOne();
		}

		string CreateXmlElement(string elem, int ord)
		{
			string tmp = null;
			if (ord == 1)
				tmp = String.Format("<{0}>", elem);
			else
				tmp = String.Format("</{0}>", elem);
				
			return tmp;
		}
		public string Mid(String strParam, int startIndex, int length)
		{
			string tmpstr = strParam.Substring(startIndex, length);
			return tmpstr;
		}
		private void UpdateListView() 
		{
			int ind=-1;
			for (int i=0; i<this.listView1.Items.Count;i++)
			{
				if (this.listView1.Items[i].Text == isu.symbol.ToString())
					ind=i;
				if (ind > -1) 
				{
					break;
				}
			}
			if (ind == -1)
			{
				ListViewItem newItem = new ListViewItem(isu.symbol.ToString());						
				newItem.SubItems.Add(isu.bid);
				newItem.SubItems.Add(isu.offer);
				newItem.SubItems.Add(isu.volume);
				
				this.listView1.Items.Add(newItem);	
				int i=this.listView1.Items.IndexOf(newItem);
				setRowColor(i, System.Drawing.Color.FromArgb(255, 255, 175) );
				setColColorHL(i, 0, System.Drawing.Color.FromArgb(128, 0, 0) );
				setColColorHL(i, 1, System.Drawing.Color.FromArgb(128, 0, 0) );
				this.listView1.Update();
				Thread.Sleep(300);
				setColColor(i, 0, System.Drawing.Color.FromArgb(255, 255, 175) );
				setColColor(i, 1, System.Drawing.Color.FromArgb(255, 255, 175) );
			}
			else
			{
				this.listView1.Items[ind].Text = isu.symbol.ToString();
				this.listView1.Items[ind].SubItems[1].Text = (isu.bid);
				this.listView1.Items[ind].SubItems[2].Text = (isu.offer);
				this.listView1.Items[ind].SubItems[3].Text = (isu.volume);
				setColColorHL(ind, 0, System.Drawing.Color.FromArgb(128, 0, 0) );
				setColColorHL(ind, 1, System.Drawing.Color.FromArgb(128, 0, 0) );
				this.listView1.Update();
				Thread.Sleep(300);
				setColColor(ind, 0, System.Drawing.Color.FromArgb(255, 255, 175) );
				setColColor(ind, 1, System.Drawing.Color.FromArgb(255, 255, 175) );
			}
			JobDone.Set();
		}

		private void setRowColor(int rowNum, Color colr )
		{
			for (int i=0; i<this.listView1.Items[rowNum].SubItems.Count;i++)
				if (rowNum%2 !=0)
					this.listView1.Items[rowNum].SubItems[i].BackColor = colr;
		}
		private void setColColor(int rowNum, int colNum, Color colr )
		{
			if (rowNum%2 !=0)
				this.listView1.Items[rowNum].SubItems[colNum].BackColor = colr;
			else
				this.listView1.Items[rowNum].SubItems[colNum].BackColor = System.Drawing.Color.FromArgb(248, 248, 248 );
			if (colNum==0)
			{
				this.listView1.Items[rowNum].SubItems[colNum].ForeColor = System.Drawing.Color.FromArgb(128, 0, 64);
				this.listView1.Items[rowNum].SubItems[colNum].BackColor = System.Drawing.Color.FromArgb(197, 197, 182 );
			}
			else
				this.listView1.Items[rowNum].SubItems[colNum].ForeColor = System.Drawing.Color.FromArgb(20, 20, 20 );
		}
		private void setColColorHL(int rowNum, int colNum, Color colr )
		{
			this.listView1.Items[rowNum].SubItems[colNum].BackColor = colr;
			this.listView1.Items[rowNum].SubItems[colNum].ForeColor = System.Drawing.Color.FromArgb(255, 255, 255 );
		}
		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			if (s != null)
				s.Close();
			if(t != null)
				if(t.IsAlive)
					t.Abort();
			Application.Exit();
		}

		private void menuDisConnect_Click(object sender, System.EventArgs e)
		{
			if(s != null)
				s.Close();
			sbar.Text="Click Connect";
			menuConn.Enabled=true;
		}
	}
}
