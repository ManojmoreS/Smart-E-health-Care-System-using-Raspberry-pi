using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Globalization;

using System.IO;
using System.Xml;

namespace TCPPortListener
{

    public struct Issue
    {
        public string symbol;
        public string bid;
        public string offer;
        public string volume;
    }
    public enum FileType
    {
        TextFile = 0,
        XMLFile = 1,
        URISrc = 2
    }

    public class Form1 : System.Windows.Forms.Form
    {
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem menuItem3;
        private System.Windows.Forms.MenuItem MenuExit;

        private Issue isu = new Issue();
        private FileType fileType;

        private int MaxConnected = 400;
        private int HighLightDelay = 300;

        private Encoding ASCII = Encoding.ASCII;
        private static long connectId = 0;
        private static AutoResetEvent JobDone = new AutoResetEvent(false);

        private TcpListener tcpLsn;
        private Hashtable socketHolder = new Hashtable();
        private Hashtable threadHolder = new Hashtable();
        private Hashtable userHolder = new Hashtable();
        bool keepUser;

        private Thread fThd;

        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.MenuItem MenuStartThread;
        private System.Windows.Forms.MenuItem menuClean;
        private System.Windows.Forms.StatusBar stBar;
        private System.Windows.Forms.MenuItem menuStop;
        private Label lblstatus;
        private ListBox lstData;
        private Button btnSend;
        private TextBox txtTxData;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private System.Windows.Forms.Timer timer1;
        private RichTextBox richTextBox1;
        private Button button1;
        private Label lblflag1;
        private Label lblflag2;
        private System.Windows.Forms.StatusBarPanel stpanel;
        string projetnumber = "403";
        public Form1()
        {
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            this.Text = this.Text + "-" + projetnumber;
            try
            {


                tcpLsn = new TcpListener(85);
                tcpLsn.Start();
                stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
                Thread tcpThd = new Thread(new ThreadStart(WaitingForClient));
                threadHolder.Add(connectId, tcpThd);
                tcpThd.Start();
                createColumns(ref dt);
                this.Paint += new PaintEventHandler(Form1_Paint);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);

        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.MenuStartThread = new System.Windows.Forms.MenuItem();
            this.menuStop = new System.Windows.Forms.MenuItem();
            this.stBar = new System.Windows.Forms.StatusBar();
            this.stpanel = new System.Windows.Forms.StatusBarPanel();
            this.MenuExit = new System.Windows.Forms.MenuItem();
            this.menuClean = new System.Windows.Forms.MenuItem();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.lblstatus = new System.Windows.Forms.Label();
            this.lstData = new System.Windows.Forms.ListBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtTxData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblflag1 = new System.Windows.Forms.Label();
            this.lblflag2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stpanel)).BeginInit();
            this.SuspendLayout();
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 1;
            this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.MenuStartThread,
            this.menuStop});
            this.menuItem3.Text = "Server";
            // 
            // MenuStartThread
            // 
            this.MenuStartThread.Checked = true;
            this.MenuStartThread.Index = 0;
            this.MenuStartThread.Text = "Start";
            this.MenuStartThread.Click += new System.EventHandler(this.OnMenuStart);
            // 
            // menuStop
            // 
            this.menuStop.Index = 1;
            this.menuStop.Text = "Stop";
            this.menuStop.Click += new System.EventHandler(this.OnMemuStop);
            // 
            // stBar
            // 
            this.stBar.Location = new System.Drawing.Point(0, 448);
            this.stBar.Name = "stBar";
            this.stBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.stpanel});
            this.stBar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.stBar.ShowPanels = true;
            this.stBar.Size = new System.Drawing.Size(322, 20);
            this.stBar.TabIndex = 3;
            // 
            // stpanel
            // 
            this.stpanel.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.stpanel.Name = "stpanel";
            this.stpanel.Width = 200;
            // 
            // MenuExit
            // 
            this.MenuExit.Index = 1;
            this.MenuExit.Text = "Exit";
            this.MenuExit.Click += new System.EventHandler(this.OnMenuExit);
            // 
            // menuClean
            // 
            this.menuClean.Index = 0;
            this.menuClean.Text = "Clean";
            this.menuClean.Click += new System.EventHandler(this.OnMenuClean);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem3});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuClean,
            this.MenuExit});
            this.menuItem1.Text = "File";
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Location = new System.Drawing.Point(13, 9);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(35, 13);
            this.lblstatus.TabIndex = 4;
            this.lblstatus.Text = "label1";
            // 
            // lstData
            // 
            this.lstData.FormattingEnabled = true;
            this.lstData.Location = new System.Drawing.Point(12, 38);
            this.lstData.Name = "lstData";
            this.lstData.Size = new System.Drawing.Size(292, 186);
            this.lstData.TabIndex = 5;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(228, 231);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 42);
            this.btnSend.TabIndex = 6;
            this.btnSend.Text = "Send Data";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtTxData
            // 
            this.txtTxData.Location = new System.Drawing.Point(12, 243);
            this.txtTxData.Name = "txtTxData";
            this.txtTxData.Size = new System.Drawing.Size(187, 20);
            this.txtTxData.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(164, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "label1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(164, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 328);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(291, 70);
            this.richTextBox1.TabIndex = 12;
            this.richTextBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(228, 285);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 42);
            this.button1.TabIndex = 13;
            this.button1.Text = "Insert Data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblflag1
            // 
            this.lblflag1.AutoSize = true;
            this.lblflag1.Location = new System.Drawing.Point(13, 401);
            this.lblflag1.Name = "lblflag1";
            this.lblflag1.Size = new System.Drawing.Size(0, 13);
            this.lblflag1.TabIndex = 14;
            // 
            // lblflag2
            // 
            this.lblflag2.AutoSize = true;
            this.lblflag2.Location = new System.Drawing.Point(9, 432);
            this.lblflag2.Name = "lblflag2";
            this.lblflag2.Size = new System.Drawing.Size(35, 13);
            this.lblflag2.TabIndex = 15;
            this.lblflag2.Text = "label5";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(322, 468);
            this.Controls.Add(this.lblflag2);
            this.Controls.Add(this.lblflag1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTxData);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.lstData);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.stBar);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Tcp Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stpanel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new Form1());
        }
        public void WaitingForClient()
        {
            while (true)
            {
                // Accept will block until someone connects
                Socket sckt = tcpLsn.AcceptSocket();
                if (connectId < 10000)
                    Interlocked.Increment(ref connectId);

                else
                    connectId = 1;

                if (socketHolder.Count < MaxConnected)
                {
                    while (socketHolder.Contains(connectId))
                    {
                        Interlocked.Increment(ref connectId);
                    }

                    Thread td = new Thread(new ThreadStart(ReadSocket));
                    lock (this)
                    {
                        // it is used to keep connected Sockets
                        socketHolder.Add(connectId, sckt);
                        // it is used to keep the active thread
                        threadHolder.Add(connectId, td);
                    }
                    td.Start();
                }
            }
        }
        public void ReadSocket()
        {
            // realId will be not changed for each thread, 
            // but connectId is changed. it can't be used to delete object from Hashtable
            long realId = connectId;
            int ind = -1;
            Socket s = (Socket)socketHolder[realId];
            while (true)
            {
                if (s.Connected)
                {

                    Byte[] receive = new Byte[1024];
                    try
                    {
                        // Receive will block until data coming
                        // ret is 0 or Exception happen when Socket connection is broken

                        int ret = s.Receive(receive, receive.Length, 0);

                        lstData.Items.Add("Device " + lstData.Items.Count);
                        if (ret > 0)
                        {
                            lstData.Items.Add("Device " + lstData.Items.Count);
                            string tmp = null;
                            tmp = System.Text.Encoding.ASCII.GetString(receive);
                            lblstatus.Text = "Data Len 0";
                            lblstatus.Text = tmp;
                            if (tmp.Length > 0)
                            {
                                DateTime now1 = DateTime.Now; ;
                                String strDate;
                                strDate = now1.ToShortDateString() + " "
                                                + now1.ToLongTimeString();
                                //  lstData.Items.Add("Device" + lstData.Items.Count + 1);
                                starttimer = true;
                                try
                                {
                                    if (tmp.Contains("GPRS"))
                                    {
                                        label1.Text = "Data Recv";
                                    }
                                    if (tmp.Contains("$"))
                                    {
                                        //$214$SJC$06740829$CC
                                        tmp = tmp.Replace("@", "");
                                        char b = (char) 00;
                                        char c = (char) 64;
                                        tmp = tmp.Replace(b,c);
                                        tmp = tmp.Replace("@", "");
                                        string[] data = tmp.Split('$');
                                        string collagename = " ";
                                        string projectcode = "0";
                                        string datavalue = "";
                                        string dataname = " ";
                                        if (data.Length > 1)
                                            projectcode = data[1];
                                        if (data.Length > 2)
                                            collagename = data[2];
                                        if (data.Length > 3)
                                            datavalue = data[3];
                                        if (data.Length > 4)
                                            dataname = "CC";
                                        dataname = "HW";
                                        datavalue = datavalue.Replace("@", "");
                                        datavalue = datavalue.Substring(0, 5);
                                        label1.Text = collagename;
                                        label2.Text = projectcode;
                                        datavalue = datavalue.Trim();
                                        label3.Text = datavalue.Trim();
                                        label4.Text = dataname;
                                        projectcode="403";
                                        RestClient myRestClient = new RestClient();
                                        myRestClient.EndPoint = "insert";
                                        if (projetnumber == projectcode)
                                        {
                                            //myRestClient.EndPoint = @"insert";
                                            //var json = myRestClient.MakeRequest("tablename=projectdata&columnnames=collegename,projectnumber,data,dataname,hasread,datatime&columnvalues='" + collagename + "'," + projectcode + ",'" + datavalue + "','" + dataname + "',0,now()");

                                            var json = myRestClient.MakeRequest("tablename=projectdata&columnnames=collegename,projectnumber,data,dataname,hasread,datatime&columnvalues='" + collagename + "'," + projectcode + ",'" + datavalue + "','" + dataname + "',3,now()");
                                            if (json.ToString().Contains("insertionSuccess"))
                                            {
                                                lblstatus.Text = "Insetion Success " + json.ToString();
                                            }
                                            else
                                            {
                                                lblstatus.Text = "Insetion Unsuccess " + json.ToString();
                                            }
                                        }
                                        else
                                        {
                                            lblstatus.Text = "Invalid Project code";
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message);
                                }

                            }
                        }
                        else
                        {
                            keepUser = false;
                            break;
                        }
                    }
                    catch (Exception e)
                    {
                        if (!s.Connected)
                        {
                            lstData.Items.Add("Disconnected");
                            keepUser = false;
                            break;
                        }
                    }
                }
            }
            CloseTheThread(realId);
        }

        private int checkUserInfo(string userId)
        {
            //  check the userId and password first
            // ....

            if (true)// suppose it ok
            {
                if (userHolder.ContainsValue(userId))
                {
                    keepUser = true;
                    return 1; // user is login already
                }
            }
            else
                return 0; // user not in the database
            return 2; // user is vailidate
        }
        private void CloseTheThread(long realId)
        {
            if (!keepUser) userHolder.Remove(realId);
            Thread thd = (Thread)threadHolder[realId];
            lock (this)
            {
                socketHolder.Remove(realId);
                threadHolder.Remove(realId);
            }
            thd.Abort();
        }

        private void SendDataToAllClient(string str)
        {
            try
            {


                foreach (Socket s in socketHolder.Values)
                {
                    if (s.Connected)
                    {
                        Byte[] byteData = ASCII.GetBytes(str.ToCharArray());
                        s.Send(byteData, byteData.Length, 0);
                    }
                }
            }
            catch (Exception)
            {

                SetText("Error while Sending data");
            }
        }

        private void OnMenuClean(object sender, System.EventArgs e)
        {
            this.lstData.Items.Clear();
        }

        public string Mid(String strParam, int startIndex, int length)
        {
            string tmpstr = strParam.Substring(startIndex, length);
            return tmpstr;
        }

        private void OnMenuExit(object sender, System.EventArgs e)
        {
            if (fThd.IsAlive)
                fThd.Abort();
            if (tcpLsn != null)
                tcpLsn.Stop();
            foreach (Socket s in socketHolder.Values)
            {
                if (s.Connected)
                    s.Close();
            }
            foreach (Thread t in threadHolder.Values)
            {
                if (t.IsAlive)
                    t.Abort();
            }
            Application.Exit();
        }

        private void OnMenuStart(object sender, System.EventArgs e)
        {
            if (tcpLsn == null)
            {
                tcpLsn = new TcpListener(85);
                tcpLsn.Start();
                Thread tcpThd = new Thread(new ThreadStart(WaitingForClient));
                threadHolder.Add(connectId, tcpThd);
                tcpThd.Start();
                stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
                menuStop.Checked = false;
                MenuStartThread.Checked = true;
            }
        }
        private void OnMemuStop(object sender, System.EventArgs e)
        {
            tcpLsn.Stop();
            tcpLsn = null;

            Thread tcpThd = (Thread)threadHolder[0];
            tcpThd.Abort();
            threadHolder.Remove(0);
            stpanel.Text = "Start Server Please!";
            foreach (Socket s in socketHolder.Values)
            {
                if (s.Connected)
                {
                    s.Close();
                    lstData.Items.Add("Disconnected");
                }
            }
            foreach (Thread t in threadHolder.Values)
            {
                if (t.IsAlive)
                    t.Abort();
            }
            menuStop.Checked = true;
            MenuStartThread.Checked = false;
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {

        }
        bool starttimer = false;
        private void btnSend_Click(object sender, EventArgs e)
        {
            fThd = new Thread(new ThreadStart(LoadDataThread));
            fThd.Start();
        }
        public void LoadDataThread()
        {
            SendDataToAllClient(txtTxData.Text + "@");
            fThd.Abort();
        }
        public void ReadMySqlThread()
        {
            string lastcmd = string.Empty; ;
            try
            {
                lastcmd = GetLastCommand();
                // richTextBox1.Text = "Sending...." + lastcmd;
                if (!string.IsNullOrEmpty(lastcmd))
                    SendDataToAllClient(lastcmd + "@");
                // fThd.Abort();

            }
            catch (Exception ex)
            {
                SetText("A " + lastcmd + ex.Message);
            }

        }
        delegate void SetTextCallback(string text);
        private void SetText(string text)
        {
            if (this.lblflag1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.lblflag1.Text = text;
            }
        }
        private void SetFlag(string text)
        {
            if (this.lblflag2.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.lblflag2.Text = text;
            }
        }
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (!starttimer)
                    return;
                if (timer1.Enabled)
                {
                    fThd = new Thread(new ThreadStart(ReadMySqlThread));
                    fThd.Start();
                }
            }
            catch (Exception ex)
            {
                lblstatus.Text = "Timer:" + ex.Message;
            }
        }


        DataTable dt = new DataTable();
        void createColumns(ref DataTable dtm)
        {
            dtm = new DataTable();
            dtm.Columns.Add("id");
            dtm.Columns.Add("collegename");
            dtm.Columns.Add("projectnumber");
            dtm.Columns.Add("data");
            dtm.Columns.Add("dataname");
            dtm.Columns.Add("hasread");
            // dtm.Columns.Add("userid");
            // dtm.Columns.Add("projecttitle");
            dtm.Columns.Add("datatime");
        }
        public String GetLastCommand()
        {
            DataTable dtlast = new DataTable();
            createColumns(ref dtlast);
            RestClient myRestClient = new RestClient();
            myRestClient.EndPoint = @"select";
            var json = myRestClient.MakeRequest("tablename=projectdata&columns=id,collegename,projectnumber,data,dataname,hasread,datatime&conditions=hasread=2 and projectnumber="+  projetnumber);
            if (json != null)
            {
                string[] rows = json.ToString().Split('[');
                foreach (string row in rows)
                {
                    string acitverow = row.Replace(System.Environment.NewLine, "");
                    acitverow = acitverow.Replace(@"\", "");
                    string[] columns = acitverow.Split(',');
                    if (columns != null)
                    {
                        if (columns.Length >= 7)
                        {
                            DataRow dr = dtlast.NewRow();
                            int i = 0;
                            foreach (string values in columns)
                            {
                                if (i < dt.Columns.Count)
                                {
                                    string vvalue = values.Replace(((char)34).ToString(), "");
                                    dr[i] = vvalue;

                                }

                                i++;
                            }
                            dtlast.Rows.Add(dr);
                            update(Convert.ToInt32(dtlast.Rows[0]["id"] + ""));
                            lblstatus.Text = dtlast.Rows[0]["data"] + "";
                            return dtlast.Rows[0]["data"] + "";
                        }
                    }
                }
                return "";
            }
            return "";
        }
        void update(int id)
        {
            RestClient myRestClient = new RestClient();
            myRestClient.EndPoint = @"update";
            var json = myRestClient.MakeRequest("tablename=projectdata&columns=hasread=1&conditions=id=" + id + "");
            if (json.ToString().Contains("updationSuccess"))
            {
                lblstatus.Text = "Update Successfully";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtTxData.Text = GetLastCommand();
            string[] data = txtTxData.Text.Split('$');
            string collagename = " ";
            string projectcode = "0";
            string datavalue = "";
            string dataname = " ";
            if (data.Length > 1)
                projectcode = data[1];
            if (data.Length > 2)
                collagename = data[2];
            if (data.Length > 3)
                datavalue = data[3];
            if (data.Length > 4)
                dataname = data[4];
            label1.Text = collagename;
            label2.Text = projectcode;
            label3.Text = datavalue;
            label4.Text = dataname;
            RestClient myRestClient = new RestClient();
            myRestClient.EndPoint = @"insert";
            var json = myRestClient.MakeRequest("tablename=projectdata&columnnames=collegename,projectnumber,data,dataname,hasread,datatime&columnvalues='" + collagename + "'," + projectcode + ",'" + datavalue + "','" + dataname + "',0,now()");
            //richTextBox1.Text = @"http://pragmarestwb.ap-southeast-1.elasticbeanstalk.com/rest/pragmagprsws/insert?database=pragmagprsdb&tablename=projectdata&columnnames=collegename,projectnumber,data,dataname,hasread,userid,projecttitle,datatime&columnvalues='" + collagename + "'," + projectcode + ",'" + datavalue + "','" + dataname + "',0,now()";

            if (json.ToString().Contains("insertionSuccess"))
            {
                lblstatus.Text = "Insetion Success " + json.ToString();
            }
            else
            {
                lblstatus.Text = "Insetion Unsuccess " + json.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
